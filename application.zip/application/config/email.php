<?php 
$config['email_config'] = array(
                'mailtype' => 'HTML',
                'protocol' => 'SMTP',
                'smtp_host' => 'tls://smtp.gmail.com',
                'smtp_port' => '587',
                'smtp_user' => 'mithunparmar009@gmail.com',
                'smtp_pass' => 'vixjfvvcpgprxagd',
                'charset' => 'utf-8',
                'newline' => '\r\n',
            ); 

?>